import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Sign Up - ITP107',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFFF5F6FA),
        fontFamily: 'Roboto',
      ),
      home: const SignUpScreen(),
    );
  }
}

const Color kPrimary = Color(0xFF4338CA);
const Color kAccent = Color(0xFF7C3AED);
const Color kBackground = Color(0xFFF3F1FB);

const String kCourseDescription =
    'Mobile App Development is a subject that teaches students how to '
    'design, develop, and test applications for mobile devices. It covers '
    'basic programming, user interface design, app functionality, and the '
    'use of development tools such as Flutter. The subject helps students '
    'develop practical skills in creating simple and useful mobile '
    'applications.';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _nameController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  // 1) SINGLE TAP -> "Hello World!"
  void _onSingleTap() {
    // ignore: avoid_print
    print('Single Tap Detected: Hello World!');
    _showPopup(
      title: 'Single Tap',
      message: 'Hello World!',
      color: kPrimary,
    );
  }

  // 2) DOUBLE TAP -> full course description
  void _onDoubleTap() {
    // ignore: avoid_print
    print('Double Tap Detected: $kCourseDescription');
    _showPopup(
      title: 'Double Tap · ITP107',
      message: kCourseDescription,
      color: kAccent,
    );
  }

  // 3) LONG PRESS -> whatever name was typed into the Full Name field
  void _onLongPress() {
    final String typedName = _nameController.text.trim();
    final String displayName = typedName.isEmpty ? '(no name entered)' : typedName;

    // ignore: avoid_print
    print('Long Press Detected: $displayName');
    _showPopup(
      title: 'Long Press',
      message: displayName,
      color: Colors.teal,
    );
  }

  void _showPopup({
    required String title,
    required String message,
    required Color color,
  }) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.bold, color: color),
          ),
          content: Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, color: Colors.black87),
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('OK', style: TextStyle(color: color, fontWeight: FontWeight.w600)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFEDE9FE), kBackground],
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
          children: [
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 400),
                child: Card(
                  color: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(28),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [
                        BoxShadow(
                          color: kPrimary.withValues(alpha: 0.15),
                          blurRadius: 30,
                          offset: const Offset(0, 14),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.fromLTRB(28, 44, 28, 32),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 88,
                          width: 88,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [kPrimary, kAccent],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: kPrimary.withValues(alpha: 0.35),
                                blurRadius: 16,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: Image.network(
                              'https://cdn-icons-png.flaticon.com/512/747/747376.png',
                              height: 50,
                              width: 50,
                              color: Colors.white,
                              errorBuilder: (context, error, stackTrace) =>
                                  const Icon(Icons.person_rounded,
                                      size: 50, color: Colors.white),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),

                        const Text(
                          'Create Account',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF1E1B4B),
                            letterSpacing: 0.2,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Center(
                          child: Container(
                            height: 4,
                            width: 48,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              gradient: const LinearGradient(
                                colors: [kPrimary, kAccent],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          'Fill out this form',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 13.5, color: Colors.black54),
                        ),
                        const SizedBox(height: 32),

                        _buildField(
                          icon: Icons.person_outline_rounded,
                          label: 'Full Name',
                          controller: _nameController,
                        ),
                        const SizedBox(height: 16),
                        _buildField(
                          icon: Icons.email_outlined,
                          label: 'Email Address',
                        ),
                        const SizedBox(height: 16),
                        _buildField(
                          icon: Icons.lock_outline_rounded,
                          label: 'Password',
                          obscure: true,
                        ),
                        const SizedBox(height: 30),

                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: _onSingleTap,
                          onDoubleTap: _onDoubleTap,
                          onLongPress: _onLongPress,
                          child: Container(
                            width: double.infinity,
                            height: 52,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              gradient: const LinearGradient(
                                colors: [kPrimary, kAccent],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: kPrimary.withValues(alpha: 0.4),
                                  blurRadius: 14,
                                  offset: const Offset(0, 8),
                                ),
                              ],
                            ),
                            child: const Text(
                              'Click Me',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.4,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        const Text(
                          'Tap · Hello World      Double Tap · Course Info      Long Press · Name',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 11, color: Colors.black38),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField({
    required IconData icon,
    required String label,
    TextEditingController? controller,
    bool obscure = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      textAlign: TextAlign.start,
      style: const TextStyle(fontSize: 15, color: Color(0xFF1E1B4B)),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.black45, fontSize: 13.5),
        prefixIcon: Icon(icon, color: kPrimary, size: 20),
        filled: true,
        fillColor: kBackground,
        contentPadding: const EdgeInsets.symmetric(vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: kPrimary, width: 1.4),
        ),
      ),
    );
  }
}