package com.example.tumlossignup_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
